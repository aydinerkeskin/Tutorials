﻿using ConfigurationService.DataAccess.Entities.Application;
using ConfigurationService.DataAccess.Entities.Configuration;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ConfigurationService.DataAccess.Context
{
    public class DataContext : DbContext
    {
        public DataContext(DbContextOptions<DataContext> options) : base(options) { }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            //builder.Entity<ConfigurationItem>(entity =>
            //{
            //    entity.HasOne(ci => ci.Context)
            //        .WithMany(ctx => ctx.ConfigurationItems)
            //        .HasForeignKey(ci => ci.ContextId)
            //        .HasConstraintName("FK_ConfigurationItem_Context");
            //    entity.HasOne(ci => ci.Key)
            //        .WithMany(k => k.ConfigurationItems)
            //        .HasForeignKey(ci => ci.Key)
            //        .HasConstraintName("FK_ConfigurationItem_Key");
            //});

            builder.Entity<EnvironmentConfiguration>(entity =>
            {
                entity.HasKey(k => new { k.Environment, k.ConfigurationName });
                //entity.HasOne(ec => ec.EnvironmentDefinition)
                //    .WithMany(ed => ed.EnvironmentConfigurations)
                //    .HasForeignKey(ec => ec.Environment)
                //    .HasConstraintName("FK_EnvironmentConfiguration_EnvironmentDefinition");
            });

            //builder.Entity<Entities.Configuration.Context>(entity =>
            //{
            //    entity.HasOne(ctx => ctx.Application)
            //        .WithMany(app => app.Contexts)
            //        .HasForeignKey(ctx => ctx.ApplicationId)
            //        .HasConstraintName("FK_Context_Application");
            //});

            base.OnModelCreating(builder);
        }

        public virtual void Save()
        {
            base.SaveChanges();
        }
        
        public override int SaveChanges()
        {
            return base.SaveChanges();
        }

        public override async Task<int> SaveChangesAsync(CancellationToken cancellationToken = new CancellationToken())
        {
            return await base.SaveChangesAsync(cancellationToken);
        }

        public DbSet<Application> Applications { get; set; }
        public DbSet<ConfigurationItem> ConfigurationItems { get; set; }
        public DbSet<Entities.Configuration.Context> Contexts { get; set; }
        public DbSet<Entities.Configuration.EnvironmentConfiguration> EnvironmentConfigurations { get; set; }
        public DbSet<Entities.Configuration.EnvironmentDefinition> EnvironmentDefinitions { get; set; }
        public DbSet<Entities.Configuration.Key> Keys { get; set; }
    }
}
