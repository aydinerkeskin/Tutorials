﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace ConfigurationService.DataAccess.Entities.Application
{
    [Table("Application", Schema = "Application")]
    public class Application
    {
        [Key]
        public int ApplicationId { get; set; }
        public string ApplicationName { get; set; }

        public ICollection<Configuration.Context> Contexts { get; set; } = new HashSet<Configuration.Context>();
    }
}
