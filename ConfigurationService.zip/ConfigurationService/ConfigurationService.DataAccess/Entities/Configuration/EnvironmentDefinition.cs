﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace ConfigurationService.DataAccess.Entities.Configuration
{
    [Table("EnvironmentDefinition", Schema = "Configuration")]
    public class EnvironmentDefinition
    {
        [Key]
        public string Environment { get; set; }
        public string Definition { get; set; }

        public ICollection<EnvironmentConfiguration> EnvironmentConfigurations { get; set; } = new HashSet<EnvironmentConfiguration>();
    }
}
