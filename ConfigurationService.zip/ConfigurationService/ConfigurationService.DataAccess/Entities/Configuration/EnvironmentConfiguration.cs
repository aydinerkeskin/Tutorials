﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace ConfigurationService.DataAccess.Entities.Configuration
{
    [Table("EnvironmentConfiguration", Schema = "Configuration")]
    public class EnvironmentConfiguration
    {
        public string Environment { get; set; }
        public string ConfigurationName { get; set; }
        public string Value { get; set; }

        [ForeignKey("Environment")]
        public EnvironmentDefinition EnvironmentDefinition { get; set; }
    }
}
