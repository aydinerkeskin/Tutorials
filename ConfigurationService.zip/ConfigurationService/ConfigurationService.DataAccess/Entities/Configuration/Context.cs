﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace ConfigurationService.DataAccess.Entities.Configuration
{
    [Table("Context", Schema = "Configuration")]
    public class Context
    {
        [Key]
        public int ContextId { get; set; }
        public int ApplicationId { get; set; }
        public string Name { get; set; }

        public ICollection<ConfigurationItem> ConfigurationItems { get; set; } = new HashSet<ConfigurationItem>();

        [ForeignKey("ApplicationId")]
        public Application.Application Application { get; set; }
    }
}
