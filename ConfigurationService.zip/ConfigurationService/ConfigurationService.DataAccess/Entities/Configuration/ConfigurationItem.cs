﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace ConfigurationService.DataAccess.Entities.Configuration
{
    [Table("ConfigurationItem", Schema = "Configuration")]
    public class ConfigurationItem
    {
        [Key]
        public int ConfigurationItemId { get; set; }
        public int? ContextId { get; set; }
        public int KeyId { get; set; }
        public string Value { get; set; }

        [ForeignKey("ContextId")]
        public Entities.Configuration.Context Context { get; set; }
        [ForeignKey("KeyId")]
        public Entities.Configuration.Key Key { get; set; }
    }
}
