﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ConfigurationService.DataAccess.Repository;
using Microsoft.AspNetCore.Mvc;

namespace ConfigurationService.Controllers
{
    [Route("api/application")]
    public class ApplicationController : Controller
    {
        private IUnitOfWork _unitOfWork;
        private IGenericRepository<DataAccess.Entities.Application.Application> _applicationRepository;
        private IGenericRepository<DataAccess.Entities.Configuration.ConfigurationItem> _configurationItemRepository;

        public ApplicationController(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;

            _applicationRepository = _unitOfWork.GetRepository<DataAccess.Entities.Application.Application>();
            _configurationItemRepository = _unitOfWork.GetRepository<DataAccess.Entities.Configuration.ConfigurationItem>();
        }

        public IActionResult Index()
        {
            var mApplications = _applicationRepository.GetAll().ToList();
            
            var mConfigurationItems = _configurationItemRepository.GetAll().ToList();

            return Ok(mApplications);
        }
    }
}