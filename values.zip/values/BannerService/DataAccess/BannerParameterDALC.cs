﻿using CommonLibrary.DataAccess;
using ServiceContract.Contracts.BannerService;
using System.Collections.Generic;
using System.Data;

namespace BannerService.DataAccess
{
    public class BannerParameterDALC : EntityBaseDataAccess<BannerParameter>
    {
        protected override BannerParameter GetItemFromReader(IDataReader dr)
        {
            BannerParameter temp = new BannerParameter();
            temp.BannerParameterId = dr.GetInt32("BannerParameterId");
            temp.ParameterName = dr.GetString("ParameterName");
            temp.Description = dr.GetString("Description");
            return temp;
        }

        public List<BannerParameter> GetBannerParameterList()
        {
            return GetEntityList("usp_BannerParameter_Get");
        }

        public List<BannerParameter> GetParametersByViewPlaceHolderId(int viewPlaceHolderId)
        {
            return GetEntityList("usp_BannerParameter_GetParametersByViewPlaceHolderId", viewPlaceHolderId);
        }
    }
}