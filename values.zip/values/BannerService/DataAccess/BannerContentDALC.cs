﻿using CommonLibrary.DataAccess;
using CommonLibrary.Utils;
using ServiceContract.Contracts.BannerService;
using System;
using System.Collections.Generic;
using System.Data;

namespace BannerService.DataAccess
{
    public class BannerContentDALC : EntityBaseDataAccess<BannerContent>
    {
        protected override BannerContent GetItemFromReader(IDataReader dr)
        {
            BannerContent temp = new BannerContent();
            temp.BannerContentId = dr.GetInt32("BannerContentId");
            temp.BannerId = dr.GetInt32("BannerId");
            temp.RegionId = dr.GetByte("RegionId");
            temp.Culture = dr.GetString("Culture");
            temp.BannerHtml = dr.GetString("BannerHtml");
            temp.StartDate = dr.GetDateTime("StartDate");
            temp.EndDate = dr.GetDateTime("EndDate");
            temp.BannerContentStatus = (BannerContentStatus)dr.GetByte("StatusId");
            return temp;
        }

        public int BannerContentInsert(int bannerId, short regionId, string culture, string bannerHtml, DateTime startDate, DateTime endDate, BannerContentStatus status)
        {
            return InsertEntity("usp_BannerContent_Insert", bannerId, regionId, culture, bannerHtml, startDate, endDate, status.ToInt());
        }

        public bool UpdateBannerContent(int bannerId, short regionId, string culture, string bannerHtml, DateTime startDate, DateTime endDate, BannerContentStatus status)
        {
            return ExecuteNonQuery("usp_BannerContent_Update", bannerId, regionId, culture, bannerHtml, startDate, endDate, status.ToInt()) > 0;
        }

        public bool UpdateBannerContentStatus(int bannerId, short regionId, string culture, BannerContentStatus status)
        {
            return ExecuteNonQuery("usp_BannerContent_UpdateStatus", bannerId, regionId, culture, status.ToInt()) > 0;
        }

        public List<BannerContent> GetBannerContentList()
        {
            return GetEntityList("usp_BannerContent_Get");
        }
    }
}