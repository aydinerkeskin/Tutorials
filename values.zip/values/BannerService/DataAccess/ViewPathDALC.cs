﻿using CommonLibrary.DataAccess;
using ServiceContract.Contracts.BannerService;
using System.Collections.Generic;
using System.Data;

namespace BannerService.DataAccess
{
    public class ViewPathDALC : EntityBaseDataAccess<ViewPath>
    {
        protected override ViewPath GetItemFromReader(IDataReader dr)
        {
            ViewPath temp = new ViewPath();
            temp.ViewPathId = dr.GetInt32("ViewPathId");
            temp.ViewId = dr.GetInt32("ViewId");
            temp.Culture = dr.GetString("Culture");
            temp.Path = dr.GetString("Path");
            return temp;
        }

        public List<ViewPath> GetViewPathList()
        {
            return GetEntityList("usp_ViewPath_Get");
        }
    }
}