﻿using CommonLibrary.DataAccess;
using ServiceContract.Contracts.BannerService;
using System.Collections.Generic;
using System.Data;

namespace BannerService.DataAccess
{
    public class BannerParamsDALC : EntityBaseDataAccess<BannerParams>
    {
        protected override BannerParams GetItemFromReader(IDataReader dr)
        {
            BannerParams temp = new BannerParams();
            temp.BannerId = dr.GetInt32("BannerId");
            temp.ParameterName = dr.GetString("ParameterName");
            temp.Value = dr.GetString("Value");
            return temp;
        }

        public List<BannerParams> GetBannerParams(string viewName, string placeHolderName, string culture)
        {
            return GetEntityList("usp_ViewBanner_Get_byViewAndPlaceHolderAndCulture", viewName, placeHolderName, culture);
        }
    }
}