﻿using CommonLibrary.DataAccess;
using ServiceContract.Contracts.BannerService;
using System.Collections.Generic;
using System.Data;

namespace BannerService.DataAccess
{
    public class ViewDALC : EntityBaseDataAccess<View>
    {
        protected override View GetItemFromReader(IDataReader dr)
        {
            View temp = new View();
            temp.ViewId = dr.GetInt32("ViewId");
            temp.ViewName = dr.GetString("ViewName");
            return temp;
        }

        public List<View> GetViewList()
        {
            return GetEntityList("usp_View_Get");
        }
    }
}