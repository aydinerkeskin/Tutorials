﻿using CommonLibrary.DataAccess;
using CommonLibrary.Utils;
using ServiceContract.Contracts.BannerService;
using System.Collections.Generic;   
using System.Data;

namespace BannerService.DataAccess
{
    public class BannerDALC : EntityBaseDataAccess<Banner>
    {
        protected override Banner GetItemFromReader(IDataReader dr)
        {
            Banner temp = new Banner();
            temp.BannerId = dr.GetInt32("BannerId"); 
            temp.BannerName = dr.GetString("BannerName");
            temp.Status = (BannerStatus)dr.GetByte("StatusId");  
            return temp;
        }

        public List<Banner> GetBannerList()
        {
            return GetEntityList("usp_Banner_Get");
        }

        public int BannerInsert(string bannerName, BannerStatus status)
        {
            return InsertEntity("usp_Banner_Insert", bannerName, status.ToInt());
        }

        public bool UpdateBannerStatus(int bannerId, BannerStatus status)
        {
            return ExecuteNonQuery("usp_Banner_Update_Status", bannerId, status.ToInt()) > 0;
        }

        public bool UpdateBannerName(int bannerId, string bannerName)
        {
            return ExecuteNonQuery("usp_Banner_Update_Name", bannerId, bannerName) > 0;
        }
    }
}