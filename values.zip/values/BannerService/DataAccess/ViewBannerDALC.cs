﻿using CommonLibrary.DataAccess;
using CommonLibrary.Utils;
using ServiceContract.Contracts.BannerService;
using System.Collections.Generic;
using System.Data;

namespace BannerService.DataAccess
{
    public class ViewBannerDALC : EntityBaseDataAccess<ViewBanner>
    {
        protected override ViewBanner GetItemFromReader(IDataReader dr)
        {
            ViewBanner temp = new ViewBanner();
            temp.ViewBannerId = dr.GetInt32("ViewBannerId");
            temp.ViewPlaceHolderId = dr.GetInt32("ViewPlaceHolderId");
            temp.BannerId = dr.GetInt32("BannerId");
            temp.Status = (ViewBannerStatus)dr.GetByte("StatusId");
            return temp;
        }

        public int ViewBannerInsert(int viewPlaceHolderId, int bannerId, ViewBannerStatus status)
        {
            return InsertEntity("usp_ViewBanner_Insert", viewPlaceHolderId, bannerId, status.ToInt());
        }

        public bool UpdateViewBanner(int viewPlaceHolderId, int bannerId, ViewBannerStatus status)
        {
            return ExecuteNonQuery("usp_ViewBanner_Update", viewPlaceHolderId, bannerId, status.ToInt()) > 0;
        }

        public List<ViewBanner> GetViewBannerList()
        {
            return GetEntityList("usp_ViewBanner_Get");
        }
    }
}