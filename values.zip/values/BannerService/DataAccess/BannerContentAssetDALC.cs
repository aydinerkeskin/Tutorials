﻿using CommonLibrary.DataAccess;
using CommonLibrary.Utils;
using ServiceContract.Contracts.BannerService;
using System.Collections.Generic;
using System.Data;

namespace BannerService.DataAccess
{
    public class BannerContentAssetDALC : EntityBaseDataAccess<BannerContentAsset>
    {
        protected override BannerContentAsset GetItemFromReader(IDataReader dr)
        {
            BannerContentAsset temp = new BannerContentAsset();
            temp.BannerContentAssetId = dr.GetInt32("BannerContentAssetId");
            temp.BannerContentId = dr.GetInt32("BannerContentId");
            temp.Type = (BannerContentAssetType)dr.GetByte("TypeId");
            temp.FilePath = dr.GetString("FilePath");
            temp.Width = dr.GetNullableInt32("Width");
            temp.Height = dr.GetNullableInt32("Height");
            temp.Status = (BannerContentAssetStatus)dr.GetByte("StatusId");
            return temp; 
        }

        public int BannerContentAssetInsert(int bannerContentId, BannerContentAssetType type, string filePath, int? width, int? height, BannerContentAssetStatus status)
        {
            return InsertEntity("usp_BannerContentAsset_Insert", bannerContentId, type.ToInt(), filePath, width, height, status.ToInt()); 
        }

        public bool UpdateBannerContentAsset(int bannerContentAssetId, BannerContentAssetStatus status)
        {
            return ExecuteNonQuery("usp_BannerContentAsset_Update_Status", bannerContentAssetId, status.ToInt()) > 0;
        }

        public List<BannerContentAsset> GetBannerContentAssetList()
        {
            return GetEntityList("usp_BannerContentAsset_Get");
        }
    }
}