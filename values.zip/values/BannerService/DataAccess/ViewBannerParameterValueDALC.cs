﻿using CommonLibrary.DataAccess;
using ServiceContract.Contracts.BannerService;
using System.Collections.Generic;
using System.Data;

namespace BannerService.DataAccess
{
    public class ViewBannerParameterValueDALC : EntityBaseDataAccess<ViewBannerParameterValue>
    {
        protected override ViewBannerParameterValue GetItemFromReader(IDataReader dr)
        {
            ViewBannerParameterValue temp = new ViewBannerParameterValue();
            temp.ViewBannerParameterValueId = dr.GetInt32("ViewBannerParameterValueId");
            temp.ViewBannerId = dr.GetInt32("ViewBannerId");
            temp.BannerParameterId = dr.GetInt32("BannerParameterId");
            temp.BannerParameterItemId = dr.GetInt32("BannerParameterItemId");
            temp.BannerParameterItemValue = dr.GetString("BannerParameterItemValue");
            return temp;
        }

        public List<ViewBannerParameterValue> GetViewBannerParameterValueList()
        {
            return GetEntityList("usp_ViewBannerParameterValue_Get");
        }

        public bool DeleteViewBannerParameterValue(int viewBannerId, int bannerParameterId)
        {
            return ExecuteNonQuery("usp_ViewBannerParameterValue_Delete", viewBannerId, bannerParameterId) > 0;
        }

        public bool UpdateViewBannerParameterValue(int viewBannerId, int bannerParameterId, int bannerParameterItemId)
        {
            return ExecuteNonQuery("usp_ViewBannerParameterValue_Update", viewBannerId, bannerParameterId, bannerParameterItemId) > 0;
        }

        public int InsertViewBannerParameterValue(int viewBannerId, int bannerParameterId, int bannerParameterItemId)
        {
            return InsertEntity("usp_ViewBannerParameterValue_Insert", viewBannerId, bannerParameterId, bannerParameterItemId); 
        }
    }
}