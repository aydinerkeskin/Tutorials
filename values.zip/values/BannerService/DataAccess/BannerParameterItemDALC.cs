﻿using CommonLibrary.DataAccess;
using ServiceContract.Contracts.BannerService;
using System.Collections.Generic;
using System.Data;

namespace BannerService.DataAccess
{
    public class BannerParameterItemDALC : EntityBaseDataAccess<BannerParameterItem>
    {
        protected override BannerParameterItem GetItemFromReader(IDataReader dr)
        {
            BannerParameterItem temp = new BannerParameterItem();
            temp.BannerParameterItemId = dr.GetInt32("BannerParameterItemId");
            temp.BannerParameterId = dr.GetInt32("BannerParameterId");
            temp.BannerParameterItemValue = dr.GetString("BannerParameterItemValue");
            temp.BannerParameterItemMask = dr.GetString("BannerParameterItemMask");
            temp.BannerParameterItemDescription = dr.GetString("BannerParameterItemDescription");
            return temp;
        }

        public List<BannerParameterItem> GetBannerParameterItemList()
        {
            return GetEntityList("[usp_BannerParameterItem_Get]");
        }
    }
}