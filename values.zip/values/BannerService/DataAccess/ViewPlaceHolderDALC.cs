﻿using CommonLibrary.DataAccess;
using ServiceContract.Contracts.BannerService;
using System.Collections.Generic;
using System.Data;

namespace BannerService.DataAccess
{
    public class ViewPlaceHolderDALC : EntityBaseDataAccess<ViewPlaceHolder>
    {
        protected override ViewPlaceHolder GetItemFromReader(IDataReader dr)
        {
            ViewPlaceHolder temp = new ViewPlaceHolder();
            temp.ViewPlaceHolderId = dr.GetInt32("ViewPlaceHolderId");
            temp.ViewId = dr.GetInt32("ViewId");
            temp.PlaceHolderName = dr.GetString("PlaceHolderName");
            return temp;
        }

        public List<ViewPlaceHolder> GetViewPlaceHolderList()
        {
            return GetEntityList("usp_ViewPlaceHolder_Get");
        }
    }
}