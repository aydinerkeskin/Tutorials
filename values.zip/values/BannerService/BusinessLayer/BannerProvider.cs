﻿using BannerService.DataAccess;
using ServiceContract.Contracts.BannerService;
using ServiceContract.Contracts.Common;
using System;
using System.Collections.Generic;

namespace BannerService.BusinessLayer
{
    public class BannerProvider
    {
        private static volatile BannerProvider instance;
        private static object syncRoot = new object();

        private static volatile BannerContentDALC bannerContentDalc;
        private static volatile BannerContentAssetDALC bannerContentAssetDalc;
        private static volatile BannerDALC bannerDalc;
        private static volatile ViewBannerDALC viewBannerDalc;
        private static volatile BannerParameterDALC bannerParameterDalc;
        private static volatile BannerParameterItemDALC bannerParameterItemDalc;
        private static volatile ViewBannerParameterValueDALC viewBannerParameterValueDalc;
        private static volatile ViewDALC viewDalc;
        private static volatile ViewPathDALC viewPathDalc;
        private static volatile ViewPlaceHolderDALC viewPlaceHolderDALC;
        
        private static List<BannerContent> contents { get; set; }
        private static List<BannerContentAsset> assets { get; set; }
        private static List<Banner> banners { get; set; }
        private static List<ViewBanner> viewBanners { get; set; }
        private static List<BannerParameter> bannerParameters { get; set; }
        private static List<BannerParameterItem> bannerParameterItems { get; set; }
        private static List<ViewBannerParameterValue> viewBannerParameterValues { get; set; }
        private static List<View> views { get; set; }
        private static List<ViewPath> viewPaths { get; set; }
        private static List<ViewPlaceHolder> viewPlaceHolders { get; set; }

        private static object lckObjectBannerContent = new object();
        /*private static object lckObjectBannerContentAsset = new object();
        private static object lckObjectViewBanner = new object();*/
        

        public static BannerProvider GetInstance()
        {
            if (instance == null)
                lock (syncRoot)
                    if (instance == null)
                        instance = new BannerProvider();
            return instance;
        }

        public BannerProvider()
        {
            bannerContentDalc = new BannerContentDALC();
            bannerContentAssetDalc = new BannerContentAssetDALC();
            bannerDalc = new BannerDALC();
            viewBannerDalc = new ViewBannerDALC();
            bannerParameterDalc = new BannerParameterDALC();
            bannerParameterItemDalc = new BannerParameterItemDALC();
            viewBannerParameterValueDalc = new ViewBannerParameterValueDALC();
            viewDalc = new ViewDALC();
            viewPathDalc = new ViewPathDALC();
            viewPlaceHolderDALC = new ViewPlaceHolderDALC();
        }

        public int BannerContentInsert(int bannerId, byte regionId, string culture, string bannerHtml, DateTime startDate, DateTime endDate, BannerContentStatus status)
        {
            int bannerContentId = bannerContentDalc.BannerContentInsert(bannerId, regionId, culture, bannerHtml, startDate, endDate, status);
            if (bannerContentId > 0)
                contents = null;
            return bannerContentId;
        }

        public bool UpdateBannerContent(int bannerId, byte regionId, string culture, string bannerHtml, DateTime startDate, DateTime endDate, BannerContentStatus status)
        {
            bool result = bannerContentDalc.UpdateBannerContent(bannerId, regionId, culture, bannerHtml, startDate, endDate, status);
            if (result)
                contents = null;
            return result;
        }

        public bool UpdateBannerContentStatus(int bannerId, byte regionId, string culture, BannerContentStatus status)
        {
            bool result = bannerContentDalc.UpdateBannerContentStatus(bannerId, regionId, culture, status);
            if (result)
                contents = null;
            return result;
        }

        public List<BannerContent> GetBannerContentList()
        {
            if (contents == null)
            {
                lock (lckObjectBannerContent)
                {
                    if (contents == null)
                    {
                        contents = bannerContentDalc.GetBannerContentList();
                    }
                }
            }
            return contents;
        }

        public int BannerContentAssetInsert(int bannerContentId, BannerContentAssetType type, string filePath, int? width, int? height, BannerContentAssetStatus status)
        {
            int bannerContentImageId = bannerContentAssetDalc.BannerContentAssetInsert(bannerContentId, type, filePath, width, height, status);
            if (bannerContentImageId > 0)
                assets = null;
            return bannerContentImageId; 
        }

        public bool UpdateBannerContentAsset(int bannerContentAssetId, BannerContentAssetStatus status)
        {
            bool result = bannerContentAssetDalc.UpdateBannerContentAsset(bannerContentAssetId, status);
            if (result)
                assets = null;
            return result;
        }

        public List<BannerContentAsset> GetBannerContentAssetList()
        {
            if (assets == null)
                assets = bannerContentAssetDalc.GetBannerContentAssetList();  
            return assets;
        }

        public List<Banner> GetBannerList() 
        {
            if (banners == null)
                banners = bannerDalc.GetBannerList();
            return banners; 
        }

        public bool UpdateBannerStatus(int bannerId, BannerStatus status)
        {
            bool result = bannerDalc.UpdateBannerStatus(bannerId, status);
            if (result)
                banners = null;
            return result;
        }

        public bool UpdateBannerName(int bannerId, string bannerName)
        {
            bool result = bannerDalc.UpdateBannerName(bannerId, bannerName);
            if (result)
                banners = null;
            return result;
        }

        public int BannerInsert(string bannerName, BannerStatus status)
        {
            int bannerId = bannerDalc.BannerInsert(bannerName, status);
            if (bannerId > 0)
                banners = null;
            return bannerId;
        }


        public int ViewBannerInsert(int viewPlaceHolderId, int bannerId, ViewBannerStatus status)
        {
            int viewBannerId = viewBannerDalc.ViewBannerInsert(viewPlaceHolderId, bannerId, status);
            if (viewBannerId > 0)
                viewBanners = null;
            return viewBannerId;
        }

        public bool UpdateViewBanner(int viewPlaceHolderId, int bannerId, ViewBannerStatus status)
        {
            bool result = viewBannerDalc.UpdateViewBanner(viewPlaceHolderId, bannerId, status);
            if (result)
                viewBanners = null;
            return result;
        }

        public List<ViewBanner> GetViewBannerList() 
        {
            if (viewBanners == null)
                viewBanners = viewBannerDalc.GetViewBannerList();
            return viewBanners;
        }

        public List<BannerParameter> GetBannerParameterList() 
        {
            if (bannerParameters == null)
                bannerParameters = bannerParameterDalc.GetBannerParameterList();
            return bannerParameters;
        }

        public List<BannerParameter> GetParametersByViewPlaceHolderId(int viewPlaceHolderId)
        {
            return bannerParameterDalc.GetParametersByViewPlaceHolderId(viewPlaceHolderId);
        }

        public List<BannerParameterItem> GetBannerParameterItemList()
        {
            if (bannerParameterItems == null)
                bannerParameterItems = bannerParameterItemDalc.GetBannerParameterItemList();
            return bannerParameterItems;
        }

        public bool DeleteViewBannerParameterValue(int viewBannerId, int bannerParameterId)
        {
            bool result = viewBannerParameterValueDalc.DeleteViewBannerParameterValue(viewBannerId, bannerParameterId);
            if (result)
                viewBannerParameterValues = null;
            return result;
        }

        public bool UpdateViewBannerParameterValue(int viewBannerId, int bannerParameterId, int bannerParameterItemId)
        {
            bool result = viewBannerParameterValueDalc.UpdateViewBannerParameterValue(viewBannerId, bannerParameterId, bannerParameterItemId);
            if (result)
                viewBannerParameterValues = null;
            return result;
        }

        public int InsertViewBannerParameterValue(int viewBannerId, int bannerParameterId, int bannerParameterItemId)
        {
            int viewBannerParameterValue = viewBannerParameterValueDalc.InsertViewBannerParameterValue(viewBannerId, bannerParameterId, bannerParameterItemId);
            if (viewBannerParameterValue > 0)
                viewBannerParameterValues = null;
            return viewBannerParameterValue;
        }

        public List<ViewBannerParameterValue> GetViewBannerParameterValueList() 
        {
            if (viewBannerParameterValues == null)
                viewBannerParameterValues = viewBannerParameterValueDalc.GetViewBannerParameterValueList();
            return viewBannerParameterValues;
        }

        public List<View> GetViewList() 
        {
            if (views == null)
                views = viewDalc.GetViewList();
            return views;
        }

        public List<ViewPath> GetViewPathList()
        {
            if (viewPaths == null)
                viewPaths = viewPathDalc.GetViewPathList();
            return viewPaths;
        }

        public List<ViewPlaceHolder> GetViewPlaceHolderList() 
        {
            if (viewPlaceHolders == null)
                viewPlaceHolders = viewPlaceHolderDALC.GetViewPlaceHolderList();
            return viewPlaceHolders;
        }

        internal bool IsBannerExist(string bannerName)
        {
            List<Banner> banners = GetBannerList();
            return banners.Exists(b => b.BannerName == bannerName);
        }
    }
}