﻿using CommonLibrary.Configuration;
using CommonLibrary.ServiceClients;
using CommonLibrary.ServiceProvider;
using CommonLibrary.Utils;
using ICSharpCode.SharpZipLib.Core;
using ICSharpCode.SharpZipLib.Zip;
using ServiceContract.Contracts.BannerService;
using ServiceContract.Contracts.Common;
using ServiceContract.Contracts.ECommerce;
using ServiceContract.Contracts.EmailService;
using ServiceContract.Contracts.Localization;
using ServiceContract.Entities.Data;
using ServiceContract.Entities.Email;
using ServiceContract.Services;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace BannerService.BusinessLayer
{
    public class BannerManager
    {
        private BannerProvider bannerProvider;
        private Settings Settings;
        private ILocalizationServiceClient localizationServiceClient;
        private ECommerceServiceClient eCommerceServiceClient;
        private MessagingServiceClient messagingServiceClient;
        private IEmailService emailServiceClient;
        private IDataServiceClient dataServiceClient;

        private string bannerInformationMailAddress;

        private static volatile BannerManager instance;
        private static object lckObjects = new object();

        public BannerManager()
        {
            Settings = ConfigurationServiceClient.GetInstance().Settings;
            localizationServiceClient = LocalizationServiceClient.GetInstance();
            eCommerceServiceClient = ECommerceServiceClient.GetInstance();
            messagingServiceClient = MessagingServiceClient.GetInstance();
            bannerProvider = BannerProvider.GetInstance();
            emailServiceClient = ServiceProvider.GetEmailService();
            dataServiceClient = DataServiceClient.GetInstance();

            bannerInformationMailAddress = Settings["BannerService.InformationMailAddress"];
        }

        public static BannerManager GetInstance()
        {
            if (instance == null)
                lock (lckObjects)
                    if (instance == null)
                        instance = new BannerManager();
            return instance;
        }

        public Banner GetBannerById(int bannerId)
        {
            return bannerProvider.GetBannerList().Where(b => b.BannerId == bannerId).FirstOrDefault();
        }

        public ViewPlaceHolder GetPlaceHolderByViewNameAndPlaceHolderName(string viewName, string placeHolderName)
        {
            List<View> views = bannerProvider.GetViewList();
            List<ViewPlaceHolder> placeHolders = bannerProvider.GetViewPlaceHolderList();

            ViewPlaceHolder placeHolder = (from v in views
                                           join ph in placeHolders on v.ViewId equals ph.ViewId
                                           where
                                              v.ViewName == viewName
                                              && ph.PlaceHolderName == placeHolderName
                                           select new ViewPlaceHolder
                                           {
                                               ViewId = v.ViewId,
                                               ViewName = v.ViewName,
                                               PlaceHolderName = ph.PlaceHolderName,
                                               ViewPlaceHolderId = ph.ViewPlaceHolderId
                                           }).FirstOrDefault();
            return placeHolder;
        }

        public ViewBanner GetViewBannerByViewPlaceHolderIdAndBannerId(int viewPlaceHolderId, int bannerId)
        {
            return bannerProvider.GetViewBannerList().Where(vb => vb.ViewPlaceHolderId == viewPlaceHolderId && vb.BannerId == bannerId).FirstOrDefault();
        }

        public List<ViewBannerParameterValue> GetViewBannerParameterValueByViewBannerId(int viewBannerId)
        {
            return bannerProvider.GetViewBannerParameterValueList().Where(p => p.ViewBannerId == viewBannerId).ToList();
        }

        public BannerParameterItem GetBannerParameterItemByParameterAndValue(string parameter, string value)
        {
            List<BannerParameter> parameterList = bannerProvider.GetBannerParameterList();
            List<BannerParameterItem> parameterItemList = bannerProvider.GetBannerParameterItemList();

            var paramItem = (from p in parameterList
                             join pi in parameterItemList on p.BannerParameterId equals pi.BannerParameterId
                             where
                              p.ParameterName == parameter
                              && pi.BannerParameterItemValue == value
                             select pi).FirstOrDefault();

            return paramItem;
        }

        public List<BannerContent> GetBanners(BannerShowType showType, string viewName, string placeHolderName, byte regionId, string culture, Dictionary<BannerParameterEnum, string> parameters, BannerProcessType bannerProcessType, ECommerceWebContext context)
        {
            try
            {
                Global.Log(string.Format("GetBanners; From:{0}, RegionId:{1}, Culture:{2}", bannerProcessType, regionId, context.Culture), ServiceNames.BannerService);

                List<Region> regionList = eCommerceServiceClient.GetRegionList(context.Culture);
                Int32 numberOfRegions = 0;
                if (regionList != null)
                    numberOfRegions = regionList.Count;

                Global.Log(string.Format("GetBanners; From:{0}, Culture:{1}, NumberOfRegionsLoaded:{2}", bannerProcessType, context.Culture, numberOfRegions), ServiceNames.BannerService);

                //foreach (Region region in regionList)
                //    Global.Log(string.Format("GetBanners; From:{0}, Culture:{1}, RegionLoaded:{2}", bannerProcessType, context.Culture, region.RegionName), ServiceNames.BannerService);

                Region theRegion = regionList.Find(each => each.RegionId == regionId);

                if (theRegion == null)
                {
                    Global.Log(string.Format("GetBanners; Region bulunamadı : {0}", regionId), ServiceNames.BannerService);
                    return new List<BannerContent>();
                }

                string regionName = theRegion.RegionName;
                Global.Log(string.Format("GetBanners; {0} - {1} - {2} - {3}", viewName, placeHolderName, regionName, culture), ServiceNames.BannerService);

                List<BannerContent> contents = bannerProvider.GetBannerContentList();
                List<Banner> bannerList = bannerProvider.GetBannerList();
                List<ViewBanner> viewBanners = bannerProvider.GetViewBannerList();
                List<BannerParameter> parameterList = bannerProvider.GetBannerParameterList();
                List<BannerParameterItem> parameterItemList = bannerProvider.GetBannerParameterItemList();
                List<ViewBannerParameterValue> parameterValues = bannerProvider.GetViewBannerParameterValueList();
                List<View> views = bannerProvider.GetViewList();
                List<ViewPlaceHolder> placeHolders = bannerProvider.GetViewPlaceHolderList();

                List<BannerContent> selectedBanners = new List<BannerContent>();

                var query = (from vb in viewBanners
                             join b in bannerList on vb.BannerId equals b.BannerId
                             join c in contents on b.BannerId equals c.BannerId
                             join ph in placeHolders on vb.ViewPlaceHolderId equals ph.ViewPlaceHolderId
                             join v in views on ph.ViewId equals v.ViewId
                             where
                                v.ViewName == viewName
                                && ph.PlaceHolderName == placeHolderName
                                && c.RegionId == regionId
                                && c.Culture == culture
                                && b.Status != BannerStatus.Deleted
                                && c.BannerContentStatus != BannerContentStatus.PreviewDeleted
                                && c.BannerContentStatus != BannerContentStatus.LiveDeleted
                                && vb.Status != ViewBannerStatus.Deleted
                             orderby c.EndDate, c.StartDate descending
                             select new BannerParams
                             {
                                 BannerId = vb.BannerId,
                                 StartDate = c.StartDate,
                                 EndDate = c.EndDate,
                                 BannerContentStatus = c.BannerContentStatus,
                                 BannerStatus = b.Status
                             });

                if (showType == BannerShowType.Preview)
                {
                    query = query.Where(q => q.BannerStatus == BannerStatus.Active);
                    query = query.Where(q => q.BannerContentStatus == BannerContentStatus.Preview);
                }
                else if (showType == BannerShowType.Live)
                {
                    query = query.Where(q => (q.StartDate <= DateTime.Now && q.EndDate >= DateTime.Now) || q.StartDate >= DateTime.Now);
                    query = query.Where(q => q.BannerStatus == BannerStatus.Active);
                    query = query.Where(q => q.BannerContentStatus == BannerContentStatus.Live);
                }

                List<BannerParams> bannerParams = query.ToList();

                var banners = bannerParams.GroupBy(p => p.BannerId).ToList();
                if (banners.NotNullAndNotZero())
                {
                    var paramValues = (from v in parameterValues
                                       join p in parameterList on v.BannerParameterId equals p.BannerParameterId
                                       join pi in parameterItemList on v.BannerParameterItemId equals pi.BannerParameterItemId
                                       join vb in viewBanners on v.ViewBannerId equals vb.ViewBannerId
                                       select new BannerParams
                                       {
                                           BannerId = vb.BannerId,
                                           ParameterId = p.BannerParameterId,
                                           ParameterItemId = pi.BannerParameterItemId,
                                           ParameterName = p.ParameterName,
                                           Description = p.Description,
                                           Value = pi.BannerParameterItemValue,
                                           Mask = pi.BannerParameterItemMask,
                                           ItemDescription = pi.BannerParameterItemDescription
                                       }).ToList();

                    foreach (var banner in banners)
                    {
                        BannerContent content = GetBannerContent(showType, paramValues, banner.Key, parameters, regionId, culture);
                        if (content != null)
                            selectedBanners.Add(content);
                    }
                }

                //if (bannerProcessType == BannerProcessType.BannerGet && showType == BannerShowType.Live && selectedBanners.Count == 0)
                //    SendBannerNotFoundMail(viewName, placeHolderName, regionId, culture, parameters, context);

                return selectedBanners;
            }
            catch (Exception ex)
            {
                string strParameters = string.Empty;
                if (parameters.NotNullAndNotZero())
                {
                    foreach (var par in parameters)
                        strParameters += string.Format("{0}-{1} | ", par.Key, par.Value);
                }

                Global.Log(string.Format("GetBanners; Hata: viewName;{0} - placeHolderName;{1} - regionId;{2} - culture;{3} - parameters;{4}", viewName, placeHolderName, regionId, culture, strParameters), ServiceNames.BannerService);
                Global.LogException(ex, ServiceNames.BannerService);
                return new List<BannerContent>();
            }
        }

        private void SendBannerNotFoundMail(string viewName, string placeHolderName, byte regionId, string culture, Dictionary<BannerParameterEnum, string> parameters, ECommerceWebContext context)
        {
            try
            {
                Global.Log(string.Format("SendBannerNotFoundMail; RegionId:{0}, Culture:{1}, ViewName:{2}, PlaceHolderName:{3}", regionId, culture, viewName, placeHolderName), ServiceNames.BannerService);

                string regionName = eCommerceServiceClient.GetRegionList(context.Culture).Where(each => each.RegionId == regionId).First().RegionName;
                string languageName = localizationServiceClient.GetCultures(context).Where(each => each.Code == culture).First().LanguageName;
                string messageSubject = String.Format("{0} : {1} - {2} - {3} - {4}", localizationServiceClient.Translate(Settings.ApplicationId, "svc_Banner_BannerNotFound", context.Culture), regionName, languageName, viewName, placeHolderName);

                StringBuilder sb = new StringBuilder();
                sb.AppendFormat("{0}: {1} </br>", localizationServiceClient.Translate(Settings.ApplicationId, "svc_Banner_Region", context.Culture), regionName);
                sb.AppendFormat("{0}: {1} </br>", localizationServiceClient.Translate(Settings.ApplicationId, "svc_Banner_Culture", context.Culture), languageName);
                sb.AppendFormat("{0}: {1} </br>", localizationServiceClient.Translate(Settings.ApplicationId, "svc_Banner_ViewName", context.Culture), viewName);
                sb.AppendFormat("{0}: {1} </br>", localizationServiceClient.Translate(Settings.ApplicationId, "svc_Banner_PlaceHolderName", context.Culture), placeHolderName);

                if (parameters != null && parameters.Count > 0)
                {
                    List<BannerParameter> parameterList = bannerProvider.GetBannerParameterList();
                    List<BannerParameterItem> parameterItemList = bannerProvider.GetBannerParameterItemList();

                    sb.AppendFormat("<b>{0} : <b> </br>", localizationServiceClient.Translate(Settings.ApplicationId, "svc_Banner_Parameters", context.Culture));
                    foreach (var par in parameters)
                    {
                        Global.Log(string.Format("SendBannerNotFoundMail - Parameters; Key:{0}, Value:{1}", par.Key, par.Value), ServiceNames.BannerService);

                        BannerParameter bannerParameter = parameterList.Where(each => each.BannerParameterId == (int)par.Key).FirstOrDefault();
                        BannerParameterItem bannerParameterItem = parameterItemList.Where(each => each.BannerParameterId == (int)par.Key && each.BannerParameterItemValue == par.Value).FirstOrDefault();

                        if (bannerParameter == null)
                            Global.Log(string.Format("Parametre bulunamadı - Parametre; {0}", par.Key), ServiceNames.BannerService);

                        if (bannerParameterItem == null)
                            Global.Log(string.Format("Parametre değeri bulunamadı - Parametre Değeri; {0}", par.Value), ServiceNames.BannerService);

                        if (bannerParameter != null && bannerParameterItem != null)
                            sb.AppendFormat("{0}: {1} </br>", bannerParameter.Description, bannerParameterItem.BannerParameterItemDescription);
                    }
                }

                string mailBody = sb.ToString();

                string fromName = localizationServiceClient.Translate(Settings.ApplicationId, "svc_ECommerceService_LcwEmailFromName", context.Culture);

                SendMail(Settings["BannerService.FromMailAddress"], bannerInformationMailAddress, messageSubject, mailBody, fromName);
            }
            catch (Exception ex)
            {
                Global.Log(string.Format("SendBannerNotFoundMail; viewName:{0}, placeHolderName:{1}, regionId:{2}, culture:{3}", viewName, placeHolderName, regionId, culture), ServiceNames.BannerService);

                if (parameters != null && parameters.Count > 0)
                {
                    foreach (var par in parameters)
                        Global.Log(string.Format("SendBannerNotFoundMail; Parameter: ParameterKey:{0}, ParameterValue:{1}", par.Key, par.Value), ServiceNames.BannerService);
                }

                Global.LogException(ex, ServiceNames.BannerService);
            }
        }

        private void SendMail(string from, string to, string subject, string body, string fromName)
        {
            MailQueue mail = new MailQueue();
            mail.From = from;
            mail.To = to;
            mail.Subject = subject;
            mail.Body = body;
            mail.FromName = fromName;
            MailSendRequest mailSendRequest = new MailSendRequest { Mail = mail };
            emailServiceClient.SendMail(mailSendRequest);
        }

        public BannerOperationResult BannerDefinedForAllRegionsAndCultures(BannerShowType showType, string viewName, string placeHolderName, byte regionId, string culture, Dictionary<BannerParameterEnum, string> parameters, ECommerceWebContext context)
        {
            List<BannerContent> contents = bannerProvider.GetBannerContentList();
            List<Banner> bannerList = bannerProvider.GetBannerList();
            List<ViewBanner> viewBanners = bannerProvider.GetViewBannerList();
            List<BannerParameter> parameterList = bannerProvider.GetBannerParameterList();
            List<BannerParameterItem> parameterItemList = bannerProvider.GetBannerParameterItemList();
            List<ViewBannerParameterValue> parameterValues = bannerProvider.GetViewBannerParameterValueList();
            List<View> views = bannerProvider.GetViewList();
            List<ViewPlaceHolder> placeHolders = bannerProvider.GetViewPlaceHolderList();

            List<Region> regionList = eCommerceServiceClient.GetRegionList(context.Culture);
            List<Culture> cultureList = localizationServiceClient.GetCultures(context);

            List<BannerContent> regionAndCultureList = new List<BannerContent>();
            List<BannerContent> publishBannerList = new List<BannerContent>();

            List<BannerContent> bannerContents = (from vb in viewBanners
                                                  join b in bannerList on vb.BannerId equals b.BannerId
                                                  join c in contents on b.BannerId equals c.BannerId
                                                  join ph in placeHolders on vb.ViewPlaceHolderId equals ph.ViewPlaceHolderId
                                                  join v in views on ph.ViewId equals v.ViewId
                                                  where
                                                     v.ViewName == viewName
                                                     && ph.PlaceHolderName == placeHolderName
                                                     && b.Status != BannerStatus.Deleted
                                                     && vb.Status != ViewBannerStatus.Deleted
                                                     && b.Status == BannerStatus.Active
                                                     && c.BannerContentStatus == BannerContentStatus.Preview
                                                  orderby c.EndDate, c.StartDate descending
                                                  select new BannerContent
                                                  {
                                                      BannerId = vb.BannerId,
                                                      StartDate = c.StartDate,
                                                      EndDate = c.EndDate,
                                                      BannerContentStatus = c.BannerContentStatus,
                                                      BannerStatus = b.Status,
                                                      RegionId = c.RegionId,
                                                      Culture = c.Culture,
                                                      BannerHtml = c.BannerHtml
                                                  }).ToList();

            var banners = bannerContents.GroupBy(p => p.BannerId).ToList();
            if (banners.NotNullAndNotZero())
            {
                var paramValues = (from v in parameterValues
                                   join p in parameterList on v.BannerParameterId equals p.BannerParameterId
                                   join pi in parameterItemList on v.BannerParameterItemId equals pi.BannerParameterItemId
                                   join vb in viewBanners on v.ViewBannerId equals vb.ViewBannerId
                                   select new BannerParams
                                   {
                                       BannerId = vb.BannerId,
                                       ParameterId = p.BannerParameterId,
                                       ParameterItemId = pi.BannerParameterItemId,
                                       ParameterName = p.ParameterName,
                                       Description = p.Description,
                                       Value = pi.BannerParameterItemValue,
                                       Mask = pi.BannerParameterItemMask,
                                       ItemDescription = pi.BannerParameterItemDescription
                                   }).ToList();

                foreach (var banner in banners)
                {
                    bool validBanner = IsParameterValid(parameters, paramValues.Where(p => p.BannerId == banner.Key).ToList());
                    if (validBanner)
                    {
                        Global.Log(string.Format("BannerDefinedForAllRegionsAndCultures; BannerId:{0}", banner.Key), ServiceNames.BannerService);

                        BannerContent bannerContent = bannerContents.Where(b => b.BannerId == banner.Key).First();

                        publishBannerList.Add(bannerContent);

                        if (!regionAndCultureList.Exists(r => r.RegionId == bannerContent.RegionId && r.Culture == bannerContent.Culture))
                            regionAndCultureList.Add(new BannerContent() { RegionId = bannerContent.RegionId, Culture = bannerContent.Culture });
                    }
                }
            }


            List<BannerContent> notDefinedRegionAndCultureList = new List<BannerContent>();
            List<Country> countryList = dataServiceClient.GetActiveCountryList(context.Culture);

            foreach (Region regionItem in regionList)
            {
                Country country = countryList.Find(c => c.RegionId == regionItem.RegionId);
                if (country == null)
                    continue;

                if (!regionAndCultureList.Exists(each => each.RegionId == regionItem.RegionId && each.Culture == country.CulturePrefix))
                    notDefinedRegionAndCultureList.Add(new BannerContent() { RegionId = regionItem.RegionId, Culture = country.CulturePrefix });
            }

            BannerOperationResult bannerOperationResult = new BannerOperationResult();

            if (notDefinedRegionAndCultureList.Any())
            {
                StringBuilder sb = new StringBuilder();
                sb.Append(localizationServiceClient.Translate(Settings.ApplicationId, "svc_Banner_ProcessWarningMessage", context.Culture));
                sb.Append("<br /><br />");
                sb.Append("<table>");

                var notDefinedList = notDefinedRegionAndCultureList.GroupBy(each => each.RegionId).ToList();
                if (notDefinedList.NotNullAndNotZero())
                {
                    foreach (var notDefinedItem in notDefinedList)
                    {
                        sb.Append("<tr>");
                        Region selectedRegion = regionList.Find(r => r.RegionId == notDefinedItem.Key);
                        sb.AppendFormat("<td><b>{0}</b></td>", selectedRegion.RegionName);
                        List<BannerContent> notDefinedItemList = notDefinedRegionAndCultureList.FindAll(each => each.RegionId == notDefinedItem.Key);

                        sb.Append("<td>");
                        for (int i = 0; i < notDefinedItemList.Count; i++)
                            sb.AppendFormat(i == notDefinedItemList.Count - 1 ? "{0}" : "{0}, ", cultureList.Find(r => r.Code == notDefinedItemList[i].Culture).LanguageName);

                        sb.Append("</td>");
                        sb.Append("</tr>");
                    }
                }
                sb.Append("</table>");

                bannerOperationResult.Result = true; // uyarı verilmesi amacıyla true'ya çekildi
                bannerOperationResult.Message = sb.ToString();
            }
            else
            {
                bannerOperationResult.Result = true;
                bannerOperationResult.BannerList = publishBannerList;
            }

            return bannerOperationResult;
        }

        private bool IsParameterValid(Dictionary<BannerParameterEnum, string> parameters, List<BannerParams> bannerParams)
        {
            bool result = true;
            if (parameters.NotNullAndNotZero())
            {
                result = false;

                int validParamCount = 0;
                foreach (BannerParameterEnum par in parameters.Keys)
                {
                    List<BannerParams> bpList = bannerParams.Where(p => p.ParameterName == par.ToString() && p.Value == parameters[par]).ToList();
                    if (bpList.NotNullAndNotZero())
                        validParamCount++;
                }
                if (validParamCount == bannerParams.Count && validParamCount > 0)
                    result = true;
            }
            return result;
        }

        public BannerContent GetBannerContent(BannerShowType showType, List<BannerParams> paramValues, int bannerId, Dictionary<BannerParameterEnum, string> parameters, byte regionId, string culture)
        {
            List<BannerContent> contents = bannerProvider.GetBannerContentList();
            List<Banner> bannerList = bannerProvider.GetBannerList();

            BannerContent content = null;
            List<BannerParams> bParams = paramValues.Where(p => p.BannerId == bannerId).ToList();

            if (IsParameterValid(parameters, bParams))
            {
                var query = (from c in contents
                             join b in bannerList on c.BannerId equals b.BannerId
                             where
                                c.BannerId == bannerId
                                  && c.RegionId == regionId
                                  && c.Culture == culture
                             select new BannerContent
                             {
                                 BannerContentId = c.BannerContentId,
                                 BannerId = c.BannerId,
                                 Culture = c.Culture,
                                 BannerHtml = c.BannerHtml,
                                 StartDate = c.StartDate,
                                 EndDate = c.EndDate,
                                 BannerName = b.BannerName,
                                 BannerContentStatus = c.BannerContentStatus,
                                 BannerParams = bParams,
                                 BannerStatus = b.Status
                             });

                BannerContent previewContent = query.Where(q => q.BannerContentStatus == BannerContentStatus.Preview).FirstOrDefault();
                BannerContent liveContent = query.Where(q => q.BannerContentStatus == BannerContentStatus.Live).FirstOrDefault();

                content = showType == BannerShowType.Live ? liveContent : previewContent;

                if (content != null)
                {
                    content.PublishStatus = showType == BannerShowType.All && liveContent == null ? BannerPublishStatus.NotPublished : GetBannerStatus(content.StartDate, content.EndDate);
                    content.DefaultEndDate = Convert.ToDateTime(Settings["BannerService.EndDate"]);
                }
            }

            return content;
        }

        private BannerPublishStatus GetBannerStatus(DateTime startDate, DateTime endDate)
        {
            if (endDate < DateTime.Now)
                return BannerPublishStatus.Previous;
            else if (startDate < DateTime.Now && endDate > DateTime.Now)
                return BannerPublishStatus.Current;
            else if (startDate > DateTime.Now)
                return BannerPublishStatus.Next;
            else
                return BannerPublishStatus.NotPublished;
        }

        public List<ViewPlaceHolder> GetPlaceHolderListWithView()
        {
            List<View> views = bannerProvider.GetViewList();
            List<ViewPlaceHolder> placeHolders = bannerProvider.GetViewPlaceHolderList();

            var placeHolderList = (from ph in placeHolders
                                   join v in views on ph.ViewId equals v.ViewId
                                   select new ViewPlaceHolder
                                   {
                                       ViewPlaceHolderId = ph.ViewPlaceHolderId,
                                       ViewId = ph.ViewId,
                                       PlaceHolderName = ph.PlaceHolderName,
                                       ViewName = v.ViewName,
                                       ViewPlaceHolderName = v.ViewName + (ph.PlaceHolderName != v.ViewName ? "-" + ph.PlaceHolderName : string.Empty),
                                   }).OrderBy(p => p.ViewPlaceHolderName).ThenBy(p => p.PlaceHolderName).ToList();

            return placeHolderList;
        }

        public List<ParameterValue> GetParameterValuesByViewPlaceHolderIdAndBannerId(int viewPlaceHolderId, int bannerId)
        {
            List<ViewBannerParameterValue> values = bannerProvider.GetViewBannerParameterValueList();
            List<ViewBanner> viewBanners = bannerProvider.GetViewBannerList();
            List<BannerParameter> parameters = bannerProvider.GetBannerParameterList();
            List<BannerParameterItem> items = bannerProvider.GetBannerParameterItemList();

            var parameterValues = (from v in values
                                   join vb in viewBanners on v.ViewBannerId equals vb.ViewBannerId
                                   join it in items on v.BannerParameterItemId equals it.BannerParameterItemId
                                   join p in parameters on v.BannerParameterId equals p.BannerParameterId
                                   where
                                    vb.ViewPlaceHolderId == viewPlaceHolderId
                                    && vb.BannerId == bannerId
                                   select new ParameterValue
                                   {
                                       Name = p.ParameterName,
                                       Value = it.BannerParameterItemValue,
                                       Mask = it.BannerParameterItemMask
                                   }).OrderBy(p => p.Name).ThenBy(p => p.Value).ToList();

            return parameterValues;
        }

        public List<ParameterValue> GetParameterValues()
        {
            List<BannerParameter> parameters = bannerProvider.GetBannerParameterList();
            List<BannerParameterItem> items = bannerProvider.GetBannerParameterItemList();

            var parameterValues = (from p in parameters
                                   join it in items on p.BannerParameterId equals it.BannerParameterId
                                   select new ParameterValue
                                   {
                                       Name = p.ParameterName,
                                       Value = it.BannerParameterItemValue,
                                       Mask = it.BannerParameterItemMask
                                   }).OrderBy(p => p.Name).ThenBy(p => p.Value).ToList();

            return parameterValues;
        }

        public List<BannerParameter> GetBannerParameters()
        {
            return bannerProvider.GetBannerParameterList();
        }

        public List<BannerParameter> GetParametersByViewPlaceHolderId(int viewPlaceHolderId)
        {
            return bannerProvider.GetParametersByViewPlaceHolderId(viewPlaceHolderId);
        }

        public List<BannerParameterItem> GetBannerParameterItems(int parameterId)
        {
            return bannerProvider.GetBannerParameterItemList().Where(i => i.BannerParameterId == parameterId).ToList();
        }

        public BannerParameterItem GetBannerParameterItemByBannerParameterItemId(int bannerParameterItemId)
        {
            return bannerProvider.GetBannerParameterItemList().Where(i => i.BannerParameterItemId == bannerParameterItemId).FirstOrDefault();
        }

        public bool UpdateBannerStatus(DateTime date, int bannerId, BannerStatus status, ViewPlaceHolder placeHolder, byte regionId, string culture, Dictionary<BannerParameterEnum, string> parameters, ECommerceWebContext context)
        {
            if (status == BannerStatus.Deleted)
            {
                DateTime endDate = Convert.ToDateTime(Settings["BannerService.EndDate"]);

                BannerContent selectedBanner = null, nextBanner = null;
                List<BannerContent> parallelBanners = GetParallelBanners(BannerShowType.Live, placeHolder.ViewName, placeHolder.PlaceHolderName, regionId, culture, parameters, BannerProcessType.BannerSet, context).Where(b => b.BannerId != bannerId).ToList();
                if (parallelBanners.NotNullAndNotZero())
                {
                    selectedBanner = parallelBanners.Find(p => p.StartDate <= date && p.EndDate >= date);
                    nextBanner = parallelBanners.Find(p => p.StartDate >= date && p.EndDate > date);

                    if (nextBanner != null)
                        endDate = nextBanner.StartDate;
                }

                if (selectedBanner != null)
                {
                    bannerProvider.UpdateBannerContent(selectedBanner.BannerId, regionId, culture, selectedBanner.BannerHtml, selectedBanner.StartDate, endDate, BannerContentStatus.Live);
                    bannerProvider.UpdateBannerContent(selectedBanner.BannerId, regionId, culture, selectedBanner.BannerHtml, selectedBanner.StartDate, endDate, BannerContentStatus.Preview);
                }
            }

            List<BannerContent> contents = bannerProvider.GetBannerContentList();

            BannerContent previewContent = contents.Find(c => c.BannerId == bannerId && c.RegionId == regionId && c.Culture == culture && c.BannerContentStatus == BannerContentStatus.Preview);
            if (previewContent != null)
                bannerProvider.UpdateBannerContentStatus(bannerId, regionId, culture, BannerContentStatus.PreviewDeleted);

            BannerContent liveContent = contents.Find(c => c.BannerId == bannerId && c.RegionId == regionId && c.Culture == culture && c.BannerContentStatus == BannerContentStatus.Live);
            if (liveContent != null)
                bannerProvider.UpdateBannerContentStatus(bannerId, regionId, culture, BannerContentStatus.LiveDeleted);

            return true;
        }

        public BannerContent GetBannerContentByBannerIdAndRegionAndCultureAndStatus(int bannerId, byte regionId, string culture, BannerContentStatus contentStatus)
        {
            return bannerProvider.GetBannerContentList().Where(b => b.BannerId == bannerId && b.RegionId == regionId && b.Culture == culture && b.BannerContentStatus == contentStatus).FirstOrDefault();
        }

        private Dictionary<BannerParameterEnum, string> GetParameters(Dictionary<BannerParameterEnum, string> par)
        {
            Dictionary<BannerParameterEnum, string> parameters = new Dictionary<BannerParameterEnum, string>();
            if (par != null && par.Count > 0)
            {
                foreach (var p in par)
                {
                    int bannerParameterItemId = Convert.ToInt32(p.Value);
                    BannerParameterItem bannerParameterItem = GetBannerParameterItemByBannerParameterItemId(bannerParameterItemId);
                    parameters.Add(p.Key, bannerParameterItem.BannerParameterItemValue);
                }
            }
            return parameters;
        }

        public BannerSetResponse BannerSetProcess(BannerShowType showType, string viewName, string placeHolderName, Dictionary<BannerParameterEnum, string> par, int? bannerId, string bannerName, byte regionId, string culture, string bannerHtml, DateTime startDate, List<string> files, bool publishAll, ECommerceWebContext context)
        {
            Global.Log(string.Format("BannerSetProcess; RegionId:{0}", regionId), ServiceNames.BannerService);

            string regionName = eCommerceServiceClient.GetRegionList(context.Culture).Where(each => each.RegionId == regionId).First().RegionName;
            Global.Log(string.Format("BannerSetProcess; {0} - {1} - {2} - {3} - {4}", viewName, placeHolderName, regionName, culture, bannerName), ServiceNames.BannerService);

            BannerSetResponse response = new BannerSetResponse();

            BannerContentStatus contentStatus = showType == BannerShowType.Preview ? BannerContentStatus.Preview : BannerContentStatus.Live;
            bool result = true;

            try
            {
                Dictionary<BannerParameterEnum, string> parameters = GetParameters(par);

                List<BannerContent> parallelBanners = GetParallelBanners(showType, viewName, placeHolderName, regionId, culture, parameters, BannerProcessType.BannerSet, context);
                if ((parallelBanners == null || parallelBanners.Count == 0) && startDate > DateTime.Now)
                {
                    response.Result = false;
                    response.Message = localizationServiceClient.Translate(Settings.ApplicationId, "svc_Banner_FutureDateNotAllowed", context.Culture);
                    return response;
                }

                ViewPlaceHolder placeHolder = GetPlaceHolderByViewNameAndPlaceHolderName(viewName, placeHolderName);

                BannerOperationResult bannerOperationResult = null;

                if (bannerId.HasValue)
                {
                    if (result)
                        result = bannerProvider.UpdateBannerName(bannerId.Value, bannerName);

                    int viewBannerId = GetViewBannerByViewPlaceHolderIdAndBannerId(placeHolder.ViewPlaceHolderId, bannerId.Value).ViewBannerId;
                    ParameterProcess(viewBannerId, parameters);

                    bannerOperationResult = BannerContentProcess(showType, placeHolder, parameters, bannerId.Value, regionId, culture, bannerHtml, startDate, contentStatus, files, BannerProcessType.BannerSet, context);
                }
                else
                {
                    if (bannerProvider.IsBannerExist(bannerName))
                    {
                        return new BannerSetResponse { OperationResult = false, Message = "Bu isimde bir banner kullanılmaktadır." };
                    }

                    bannerId = bannerProvider.BannerInsert(bannerName, BannerStatus.Active);
                    int viewBannerId = bannerProvider.ViewBannerInsert(placeHolder.ViewPlaceHolderId, bannerId.Value, ViewBannerStatus.Active);
                    ParameterProcess(viewBannerId, parameters);

                    bannerOperationResult = BannerContentProcess(showType, placeHolder, parameters, bannerId.Value, regionId, culture, bannerHtml, startDate, contentStatus, files, BannerProcessType.BannerSet, context);
                }

                response.BannerId = bannerId.Value;
                response.OperationResult = bannerOperationResult.Result;

                BannerListChangedMessage message = new BannerListChangedMessage();
                message.ShowType = showType;
                message.ViewName = viewName;
                message.PlaceHolderName = placeHolderName;
                message.Parameters = parameters;
                message.RegionId = regionId;
                message.Culture = culture;
                messagingServiceClient.Publish(message);
                Global.Log(string.Format("Send to Messaging Service; {0} - {1} - {2} - {3}", viewName, placeHolderName, regionName, culture), ServiceNames.BannerService);

                if (bannerOperationResult.Result)
                {
                    response.Message = localizationServiceClient.Translate(Settings.ApplicationId, "svc_Banner_ProcessCompleted", context.Culture);
                    if (publishAll && bannerOperationResult.BannerList != null && bannerOperationResult.BannerList.Any())
                    {
                        foreach (BannerContent content in bannerOperationResult.BannerList)
                        {
                            BannerOperationResult operationResult = BannerContentProcess(showType, placeHolder, parameters, content.BannerId, content.RegionId, content.Culture, content.BannerHtml, content.StartDate, BannerContentStatus.Live, null, BannerProcessType.BannerSet, context);

                            BannerListChangedMessage newMessage = new BannerListChangedMessage();
                            newMessage.ShowType = showType;
                            newMessage.ViewName = viewName;
                            newMessage.PlaceHolderName = placeHolderName;
                            newMessage.Parameters = parameters;
                            newMessage.RegionId = content.RegionId;
                            newMessage.Culture = content.Culture;
                            messagingServiceClient.Publish(newMessage);

                            Global.Log(string.Format("Send to Messaging Service; RegionId:{0}", content.RegionId), ServiceNames.BannerService);

                            string newRegionName = eCommerceServiceClient.GetRegionList(context.Culture).Where(each => each.RegionId == content.RegionId).First().RegionName;
                            Global.Log(string.Format("Send to Messaging Service; {0} - {1} - {2} - {3}", viewName, placeHolderName, newRegionName, content.Culture), ServiceNames.BannerService);
                        }
                    }

                    response.Message += "</br>" + bannerOperationResult.Message;
                }
                else
                    response.Message = bannerOperationResult.Message;

                response.Result = true;
            }
            catch (Exception ex)
            {
                Global.Log("BannerSetProcess failed", ServiceNames.BannerService);
                Global.LogException(ex, ServiceNames.BannerService);

                response.Result = false;
                response.Message = ex.Message;
            }

            return response;
        }

        public BannerCopyResponse BannerCopy(string viewName, string placeHolderName, Dictionary<BannerParameterEnum, string> par, int bannerId, byte regionId, string culture, BannerShowType showType, List<byte> selectedRegionList, ECommerceWebContext context)
        {
            BannerCopyResponse response = new BannerCopyResponse();

            try
            {
                List<Country> countryList = dataServiceClient.GetActiveCountryList(context.Culture);
                Country country = countryList.Find(c => c.RegionId == regionId);

                List<Banner> bannerList = bannerProvider.GetBannerList();
                Banner banner = bannerList.Find(b => b.BannerId == bannerId);

                List<BannerContent> contents = bannerProvider.GetBannerContentList();
                BannerContent content = contents.Find(c => c.BannerId == bannerId && c.RegionId == regionId && c.Culture == culture && c.BannerContentStatus == BannerContentStatus.Preview);

                if (selectedRegionList.NotNullAndNotZero())
                {
                    string replaceText = string.Format("{0}/{1}", country.CulturePrefix, country.CountryCode);
                    foreach (byte selectedRegionId in selectedRegionList)
                    {
                        Country selectedCountry = countryList.Find(c => c.RegionId == selectedRegionId);
                        string bannerHtml = content.BannerHtml.Replace(replaceText, string.Format("{0}/{1}", selectedCountry.CulturePrefix, selectedCountry.CountryCode));
                        BannerSetResponse bannerSetResponse = BannerSetProcess(showType, viewName, placeHolderName, par, bannerId, banner.BannerName, selectedRegionId, selectedCountry.CulturePrefix, bannerHtml, content.StartDate, null, false, context);
                        Global.Log(string.Format("Kopyalanan Banner: {0} ; {1} - {2} - {3} - {4}", bannerId, viewName, placeHolderName, selectedCountry.CountryName, bannerSetResponse.Message), ServiceNames.BannerService);
                    }
                }

                response.Result = true;
                response.Message = "Kopyalama işlemi başarıyla gerçekleştirildi";
            }
            catch (Exception ex)
            {
                Global.Log("BannerCopy failed", ServiceNames.BannerService);
                Global.LogException(ex, ServiceNames.BannerService);

                response.Result = false;
                response.Message = ex.Message;
            }

            return response;
        }

        public List<int> BannerContentAssetInsertForFiles(List<string> files, int bannerContentId)
        {
            List<int> bannerContentAssetIdList = new List<int>();
            if (files.NotNullAndNotZero())
            {
                List<BannerContentAsset> assets = GetBannerAssets(bannerContentId);
                List<string> filesForInsert = files.Where(each => assets.Where(asset => asset.FilePath == each).Count() == 0).ToList();

                foreach (string file in filesForInsert)
                {
                    int BannerContentAssetId = bannerProvider.BannerContentAssetInsert(bannerContentId, BannerContentAssetTypeByFilePath(file), file, null, null, BannerContentAssetStatus.Active);
                    bannerContentAssetIdList.Add(BannerContentAssetId);
                }
            }
            return bannerContentAssetIdList;
        }

        public BannerOperationResult BannerContentProcess(BannerShowType showType, ViewPlaceHolder placeHolder, Dictionary<BannerParameterEnum, string> parameters, int bannerId, byte regionId, string culture, string bannerHtml, DateTime startDate, BannerContentStatus contentStatus, List<string> files, BannerProcessType bannerProcessType, ECommerceWebContext context)
        {
            BannerOperationResult bannerOperationResult = new BannerOperationResult();
            bannerOperationResult.Result = true;

            DateTime bannerServiceEndDate = Convert.ToDateTime(Settings["BannerService.EndDate"]);
            DateTime endDate = bannerServiceEndDate;

            BannerContent selectedBanner = null, nextBanner = null;
            List<BannerContent> banners = GetParallelBanners(showType, placeHolder.ViewName, placeHolder.PlaceHolderName, regionId, culture, parameters, bannerProcessType, context);
            List<BannerContent> parallelBanners = banners.Where(b => b.BannerId != bannerId).ToList();
            if (parallelBanners.NotNullAndNotZero())
            {
                selectedBanner = parallelBanners.Find(p => p.StartDate <= startDate && p.EndDate > startDate);
                nextBanner = parallelBanners.Find(p => p.StartDate > startDate && p.EndDate > startDate);

                if (parallelBanners.Count == 1)
                    endDate = Convert.ToDateTime(Settings["BannerService.EndDate"]);
                else if (nextBanner != null)
                    endDate = nextBanner.StartDate;
                else if (selectedBanner != null)
                    endDate = selectedBanner.EndDate;
            }

            if (selectedBanner != null)
            {
                selectedBanner.EndDate = startDate;
                if (contentStatus == BannerContentStatus.Live)
                {
                    bannerProvider.UpdateBannerContent(selectedBanner.BannerId, regionId, culture, selectedBanner.BannerHtml, selectedBanner.StartDate, startDate, BannerContentStatus.Preview);

                    bannerOperationResult = BannerDefinedForAllRegionsAndCultures(showType, placeHolder.ViewName, placeHolder.PlaceHolderName, regionId, culture, parameters, context);
                    if (bannerOperationResult.Result)
                        bannerProvider.UpdateBannerContent(selectedBanner.BannerId, regionId, culture, selectedBanner.BannerHtml, selectedBanner.StartDate, startDate, BannerContentStatus.Live);
                }
            }

            if (contentStatus == BannerContentStatus.Live)
            {
                BannerContent content = ContentProcess(bannerId, regionId, culture, bannerHtml, startDate, endDate, BannerContentStatus.Preview);
                if (content.BannerContentId > 0)
                    BannerContentAssetInsertForFiles(files, content.BannerContentId);

                bannerOperationResult = BannerDefinedForAllRegionsAndCultures(showType, placeHolder.ViewName, placeHolder.PlaceHolderName, regionId, culture, parameters, context);
                if (bannerOperationResult.Result)
                {
                    content = ContentProcess(bannerId, regionId, culture, bannerHtml, startDate, endDate, BannerContentStatus.Live);
                    if (content.BannerContentId > 0)
                        BannerContentAssetInsertForFiles(files, content.BannerContentId);
                }
            }
            else
            {
                BannerContent content = ContentProcess(bannerId, regionId, culture, bannerHtml, startDate, endDate, BannerContentStatus.Preview);
                if (content.BannerContentId > 0)
                    BannerContentAssetInsertForFiles(files, content.BannerContentId);
            }

            banners = GetParallelBanners(showType, placeHolder.ViewName, placeHolder.PlaceHolderName, regionId, culture, parameters, bannerProcessType, context);
            BannerContent lastBanner = banners.OrderBy(b => b.EndDate).Last();
            if (lastBanner != null && lastBanner.EndDate != bannerServiceEndDate)
            {
                bannerProvider.UpdateBannerContent(lastBanner.BannerId, regionId, culture, lastBanner.BannerHtml, lastBanner.StartDate, bannerServiceEndDate, BannerContentStatus.Preview);
                bannerProvider.UpdateBannerContent(lastBanner.BannerId, regionId, culture, lastBanner.BannerHtml, lastBanner.StartDate, bannerServiceEndDate, BannerContentStatus.Live);
            }

            return bannerOperationResult;
        }

        public BannerContent ContentProcess(int bannerId, byte regionId, string culture, string bannerHtml, DateTime startDate, DateTime endDate, BannerContentStatus contentStatus)
        {
            BannerContent content = GetBannerContentByBannerIdAndRegionAndCultureAndStatus(bannerId, regionId, culture, contentStatus);
            if (content == null)
            {
                content = new BannerContent();
                content.BannerId = bannerId;
                content.RegionId = regionId;
                content.Culture = culture;
                content.BannerHtml = bannerHtml;
                content.StartDate = startDate;
                content.EndDate = endDate;
                content.BannerContentStatus = contentStatus;
                content.BannerContentId = bannerProvider.BannerContentInsert(bannerId, regionId, culture, bannerHtml, startDate, endDate, contentStatus);
            }
            else
            {
                bool result = bannerProvider.UpdateBannerContent(content.BannerId, regionId, culture, bannerHtml, startDate, endDate, content.BannerContentStatus);

                content.BannerHtml = bannerHtml;
                content.StartDate = startDate;
                content.EndDate = endDate;
            }
            return content;
        }

        public void ParameterProcess(int viewBannerId, Dictionary<BannerParameterEnum, string> parameters)
        {
            List<BannerParameterEnum> processedParameter = new List<BannerParameterEnum>();

            List<ViewBannerParameterValue> values = GetViewBannerParameterValueByViewBannerId(viewBannerId);
            foreach (ViewBannerParameterValue v in values)
            {
                BannerParameterEnum parEnum = (BannerParameterEnum)v.BannerParameterId;

                if (parameters.NotNullAndNotZero())
                {
                    var par = parameters.Where(p => p.Key == parEnum);
                    if (!par.Any())
                        bannerProvider.DeleteViewBannerParameterValue(viewBannerId, v.BannerParameterId);
                    else
                    {
                        var item = par.First();
                        if (item.Value != v.BannerParameterItemValue)
                        {
                            BannerParameterItem parameterItem = GetBannerParameterItemByParameterAndValue(item.Key.ToString(), item.Value);
                            if (parameterItem != null)
                                bannerProvider.UpdateViewBannerParameterValue(viewBannerId, parameterItem.BannerParameterId, parameterItem.BannerParameterItemId);
                        }
                    }
                }
                else
                    bannerProvider.DeleteViewBannerParameterValue(viewBannerId, v.BannerParameterId);

                processedParameter.Add(parEnum);
            }

            if (parameters.NotNullAndNotZero())
            {
                foreach (var p in parameters)
                {
                    if (!processedParameter.Contains(p.Key))
                    {
                        BannerParameterItem parameterItem = GetBannerParameterItemByParameterAndValue(p.Key.ToString(), p.Value);
                        if (parameterItem != null)
                            bannerProvider.InsertViewBannerParameterValue(viewBannerId, parameterItem.BannerParameterId, parameterItem.BannerParameterItemId);
                    }
                }
            }
        }

        private List<BannerContent> GetParallelBanners(BannerShowType showType, string viewName, string placeHolderName, byte regionId, string culture, Dictionary<BannerParameterEnum, string> parameters, BannerProcessType bannerProcessType, ECommerceWebContext context)
        {
            List<BannerContent> banners = GetBanners(showType, viewName, placeHolderName, regionId, culture, parameters, bannerProcessType, context);
            return CompareBanners(banners, parameters);
        }
        private List<BannerContent> CompareBanners(List<BannerContent> banners, Dictionary<BannerParameterEnum, string> parameters)
        {
            List<BannerContent> parallelBanners = new List<BannerContent>();

            List<BannerContent> compareBanners = banners.Where(b => b.BannerParams.Count == parameters.Count).ToList();
            if (banners.NotNullAndNotZero() && compareBanners.NotNullAndNotZero())
            {
                foreach (BannerContent banner in compareBanners)
                {
                    bool bannerFound = true;
                    foreach (BannerParams par in banner.BannerParams)
                    {
                        if (parameters.Where(p => p.Key.ToString() == par.ParameterName).Count() <= 0)
                        {
                            bannerFound = false;
                            break;
                        }
                    }

                    if (bannerFound)
                        parallelBanners.Add(banner);
                }
            }

            return parallelBanners;
        }

        private string GetViewPath(int viewId, string culture)
        {
            ViewPath viewPath = bannerProvider.GetViewPathList().Where(each => each.ViewId == viewId && each.Culture == culture).FirstOrDefault();
            if (viewPath != null)
                return viewPath.Path;
            else
                return null;
        }

        public string GetPreviewUrl(int viewPlaceHolderId, int bannerId, int regionId, string culture, ECommerceWebContext context)
        {
            Global.Log(string.Format("GetPreviewUrl; viewPlaceHolderId:{0}", viewPlaceHolderId), ServiceNames.BannerService);

            ViewPlaceHolder viewPlaceHolder = GetPlaceHolderListWithView().Where(p => p.ViewPlaceHolderId == viewPlaceHolderId).First();

            string previewUrl = GetViewPath(viewPlaceHolder.ViewId, culture);
            if (string.IsNullOrEmpty(previewUrl))
                return String.Empty;

            List<ParameterValue> bannerParameterValues = GetParameterValuesByViewPlaceHolderIdAndBannerId(viewPlaceHolder.ViewPlaceHolderId, bannerId);

            if (bannerParameterValues == null)
                return string.Empty;

            if (bannerParameterValues.GroupBy(t => t.Mask).ToList().Count < bannerParameterValues.Count || bannerParameterValues.Count < 3)
            {
                foreach (ParameterValue value in bannerParameterValues)
                    previewUrl = previewUrl.Replace("{" + value.Name + "}", value.Mask);
            }
            else if (bannerParameterValues.Count == 3 && bannerParameterValues.Count(t => t.Name == "ProductGroupId" && t.Value != "2") > 0)
            {
                previewUrl = bannerParameterValues.Count(t => t.Name == "ProductGroupId" && t.Value.Trim() == "3") > 0 ? "tr-TR/{CountryCode}/kategori/{ProductGroupId}-{GenderId}/{CategoryId}" : "tr-TR/{CountryCode}/kategori/{GenderId}-{ProductGroupId}/{CategoryId}";
                foreach (ParameterValue value in bannerParameterValues)
                    previewUrl = previewUrl.Replace("{" + value.Name + "}", value.Mask);
            }
            else
            {
                foreach (ParameterValue value in bannerParameterValues)
                    previewUrl = previewUrl.Replace("{" + value.Name + "}", value.Mask);
            }


            List<Country> countryList = dataServiceClient.GetActiveCountryList(context.Culture);
            Country country = countryList.Find(c => c.RegionId == regionId);
            if (country != null)
                previewUrl = previewUrl.Replace("{CountryCode}", country.CountryCode);

            return string.Format("{0}/{1}/?ShowType={2}&BannerId={3}&RegionId={4}", Settings["BannerService.SiteAddress"], previewUrl, BannerShowType.Preview.ToString(), bannerId.ToString(), regionId);
        }

        public BannerContentAssetType BannerContentAssetTypeByFilePath(string filepath)
        {
            return BannerContentAssetTypeByExtension(Path.GetExtension(filepath));
        }
        public BannerContentAssetType BannerContentAssetTypeByExtension(string extension)
        {
            BannerContentAssetType type = BannerContentAssetType.Image;
            switch (extension)
            {
                case ".zip":
                    type = BannerContentAssetType.Zip;
                    break;
                case ".css":
                    type = BannerContentAssetType.Css;
                    break;
                case ".js":
                    type = BannerContentAssetType.Javascript;
                    break;
                case ".swf":
                    type = BannerContentAssetType.Flash;
                    break;
                case ".jpg":
                case ".jpeg":
                case ".gif":
                case ".png":
                case ".bmp":
                case ".ico":
                    type = BannerContentAssetType.Image;
                    break;
                default:
                    type = BannerContentAssetType.Image;
                    break;
            }
            return type;
        }

        public List<string> BannerUploadProcess(int bannerContentId, string fileName, byte[] fileBytes)
        {
            List<string> files = new List<string>();
            try
            {
                string bannerRootDirectory = Settings["BannerService.SiteDirectory"];
                string siteAddress = Settings["BannerService.BannerSiteAddress"];
                string uploadPath = Settings["BannerService.UploadPath"];

                BannerContentAssetType assetType = BannerContentAssetTypeByFilePath(fileName);
                if (assetType == BannerContentAssetType.Zip)
                {
                    ZipFile zipFile = new ZipFile(new MemoryStream(fileBytes));

                    string zipDirectory = bannerRootDirectory + uploadPath.Replace("/", "\\") + Path.GetFileNameWithoutExtension(fileName);

                    if (!Directory.Exists(zipDirectory))
                        Directory.CreateDirectory(zipDirectory);

                    foreach (ZipEntry zipEntry in zipFile)
                    {
                        if (!zipEntry.IsFile)
                            continue;

                        byte[] buffer = new byte[4096];
                        Stream zipStream = zipFile.GetInputStream(zipEntry);

                        string filePath = bannerRootDirectory + uploadPath.Replace("/", "\\") + zipEntry.Name.Replace("/", "\\");

                        using (FileStream streamWriter = File.Create(filePath))
                            StreamUtils.Copy(zipStream, streamWriter, buffer);

                        files.Add(siteAddress + uploadPath + zipEntry.Name);
                    }
                }
                else
                {
                    string fullPath = bannerRootDirectory + uploadPath.Replace("/", "\\") + fileName;
                    FileStream fileStream = new FileStream(fullPath, FileMode.OpenOrCreate);
                    BinaryWriter binaryWriter = new BinaryWriter(fileStream);
                    binaryWriter.Write(fileBytes);
                    binaryWriter.Close();
                    fileStream.Close();

                    files.Add(siteAddress + uploadPath + fileName);
                }

                if (bannerContentId > 0)
                    BannerContentAssetInsertForFiles(files, bannerContentId);

                return files;
            }
            catch (Exception ex)
            {
                Global.Log("BanerUploadProcess failed", ServiceNames.BannerService);
                Global.LogException(ex, ServiceNames.BannerService);
                return files;
            }
        }

        public List<BannerContentAsset> GetBannerAssets(int bannerContentId)
        {
            try
            {
                List<BannerContent> contents = bannerProvider.GetBannerContentList();
                List<BannerContentAsset> assets = bannerProvider.GetBannerContentAssetList();

                return (from i in assets
                        join c in contents on i.BannerContentId equals c.BannerContentId
                        where
                           c.BannerContentId == bannerContentId
                           && i.Status != BannerContentAssetStatus.Deleted
                        select i).ToList();
            }
            catch (Exception ex)
            {
                Global.Log("GetBannerAssets failed", ServiceNames.BannerService);
                Global.LogException(ex, ServiceNames.BannerService);
                return null;
            }
        }

        public bool UpdateBannerContentAssetStatus(int bannerContentAssetId, BannerContentAssetStatus status)
        {
            return bannerProvider.UpdateBannerContentAsset(bannerContentAssetId, status);
        }

        public bool UpdateAssetStatus(List<int> imageIds)
        {
            try
            {
                imageIds.ForEach(each => UpdateBannerContentAssetStatus(each, BannerContentAssetStatus.Deleted));
                return true;
            }
            catch
            {
                return false;
            }
        }
    }
}