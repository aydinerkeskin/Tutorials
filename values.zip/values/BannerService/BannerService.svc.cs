﻿using BannerService.BusinessLayer;
using CommonLibrary.ServiceClients;
using ServiceContract.Contracts.BannerService;
using ServiceContract.Dispatcher;
using ServiceContract.Services;
using System.Collections.Generic;
using System.ServiceModel;

namespace BannerService
{
    [ServiceBehavior(InstanceContextMode = InstanceContextMode.Single, ConcurrencyMode = ConcurrencyMode.Multiple)]
    [ErrorHandlerBehaviour]
    public class BannerService : IBannerService
    {
        private object lckBannerManager = new object();

        private BannerManager _bannerManager;
        private BannerManager bannerManager
        {
            get
            {
                if (_bannerManager == null)
                {
                    lock (lckBannerManager)
                    {
                        if (_bannerManager == null)
                            _bannerManager = BannerManager.GetInstance();
                    }
                }
                return _bannerManager;
            }
        }

        public BannerService()
        {
            //Global.Log("BannerService Initializing", ServiceNames.BannerService);
            Global.Log("BannerService Initialized", ServiceNames.BannerService);
        }

        public ViewBannerListResponse GetBanners(ViewBannerRequest request)
        {
            ViewBannerListResponse response = new ViewBannerListResponse();
            response.ContentList = bannerManager.GetBanners(request.ShowType, request.ViewName, request.PlaceHolderName, request.Region, request.CultureInfo, request.Params, BannerProcessType.BannerGet, request.Context);
            return response;
        }

        public PlaceHolderResponse GetPlaceHolderListWithView(PlaceHolderRequest request)
        {
            PlaceHolderResponse response = new PlaceHolderResponse();
            response.PlaceHolderList = bannerManager.GetPlaceHolderListWithView();
            return response;
        }

        public BannerResponse UpdateBannerStatus(BannerRequest request)
        {
            BannerResponse response = new BannerResponse();
            response.Result = bannerManager.UpdateBannerStatus(request.ControlDate, request.BannerId, request.BannerStatus, request.ViewPlaceHolder, request.Region, request.CultureInfo, request.Parameters, request.Context);
            return response;
        }

        public BannerSetResponse BannerSetProcess(BannerSetRequest request)
        {
            BannerSetResponse response = bannerManager.BannerSetProcess(request.ShowType, request.ViewName, request.PlaceHolderName, request.Parameters, request.BannerId, request.BannerName, request.Region, request.CultureInfo, request.BannerHtml, request.StartDate, request.Files, request.PublishAll, request.Context);
            return response;
        }

        public BannerCopyResponse BannerCopy(BannerCopyRequest request)
        {
            BannerCopyResponse response = bannerManager.BannerCopy(request.ViewName, request.PlaceHolderName, request.Parameters, request.BannerId, request.BannerRegionId, request.BannerCulture, request.ShowType, request.SelectedRegionList, request.Context);
            return response;
        }

        public BannerUploadResponse BannerUploadProcess(BannerUploadRequest request)
        {
            BannerUploadResponse response = new BannerUploadResponse();
            response.FileNames = bannerManager.BannerUploadProcess(request.BannerContentId, request.FilePath, request.FileBytes);
            return response;
        }

        public BannerUploadResponse BannerUploadMultipleProcess(BannerUploadMultipleRequest request)
        {
            BannerUploadResponse response = new BannerUploadResponse();
            List<string> postedFileNameList = new List<string>();
            foreach (var httpPostedFileInfoList in request.HttpPostedFileInfoList)
            {
                var postedFileName = bannerManager.BannerUploadProcess(request.BannerContentId, httpPostedFileInfoList.FileName, httpPostedFileInfoList.File);
                foreach (var _postedFileName in postedFileName)
                {
                    postedFileNameList.Add(_postedFileName);
                }
            }

            response.FileNames = postedFileNameList;
            return response;
        }

        public BannerAssetResponse GetBannerAssets(BannerAssetRequest request)
        {
            BannerAssetResponse response = new BannerAssetResponse();
            response.List = bannerManager.GetBannerAssets(request.BannerContentId);
            return response;
        }

        public BannerAssetDeleteResponse UpdateAssetStatus(BannerAssetDeleteRequest request)
        {
            BannerAssetDeleteResponse response = new BannerAssetDeleteResponse();
            response.Result = bannerManager.UpdateAssetStatus(request.AssetIdList);
            return response;
        }

        public ParameterValueByViewPlaceHolderIdAndBannerIdResponse GetParameterValueseByViewPlaceHolderIdAndBannerId(ParameterValueByViewPlaceHolderIdAndBannerIdRequest request)
        {
            ParameterValueByViewPlaceHolderIdAndBannerIdResponse response = new ParameterValueByViewPlaceHolderIdAndBannerIdResponse();
            response.ParameterValueList = bannerManager.GetParameterValuesByViewPlaceHolderIdAndBannerId(request.ViewPlaceHolderId, request.BannerId);
            return response;
        }

        public ParameterValueResponse GetParameterValues(ParameterValueRequest request)
        {
            ParameterValueResponse response = new ParameterValueResponse();
            response.ParameterValueList = bannerManager.GetParameterValues();
            return response;
        }

        public ParameterResponse GetParameters(ParameterRequest request)
        {
            ParameterResponse response = new ParameterResponse();
            response.ParameterList = bannerManager.GetBannerParameters();
            return response;
        }

        public ParameterResponse GetParametersByViewPlaceHolderId(ParameterRequest request, int viewPlaceHolderId)
        {
            ParameterResponse response = new ParameterResponse();
            response.ParameterList = bannerManager.GetParametersByViewPlaceHolderId(viewPlaceHolderId);
            return response;
        }

        public ParameterItemResponse GetParameterItems(ParameterItemRequest request)
        {
            ParameterItemResponse response = new ParameterItemResponse();
            response.ParameterItemList = bannerManager.GetBannerParameterItems(request.ParameterId);
            return response;
        }

        public PreviewUrlResponse GetPreviewUrl(PreviewUrlRequest request)
        {
            PreviewUrlResponse response = new PreviewUrlResponse();
            response.Url = bannerManager.GetPreviewUrl(request.ViewPlaceHolderId, request.BannerId, request.Region, request.CultureInfo, request.Context);
            return response;
        }


    }
}
