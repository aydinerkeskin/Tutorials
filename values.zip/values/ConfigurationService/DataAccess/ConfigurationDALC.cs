﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using CommonLibrary.DataAccess;
using ServiceContract.Entities.Configuration;
using System.Data;
using ServiceContract.Contracts.Configuration;
using System.Collections.Specialized;

namespace ConfigurationService.DataAccess
{
    public class ConfigurationDALC : EntityBaseDataAccess<ConfigurationItem>
    {
        public int GetApplicationIdOfContext(int contextId)
        {
            return (int)base.ExecuteScalar("[Configuration].[usp_GetApplicationId_ByContextId]", contextId);
        }

        public List<ConfigurationItem> GetConfigurationOfContext(int contextId)
        {
            return base.GetEntityList("[Configuration].[usp_GetConfigurationItem_ByContextId]", contextId);
        }

        public void AddConfigurationItem(int contextId, String key, string desc, String value)
        {
            base.InsertEntity("[Configuration].[usp_InsertConfigurationItem]", contextId, key, desc, value);
        }

        public void DeleteConfigurationItem(int contextId, String key)
        {
            base.ExecuteNonQuery("[Configuration].[usp_DeleteConfigurationItem]", contextId, key);
        }

        internal bool UpdateConfigurationItem(int contextId, String key, String value)
        {
            return base.ExecuteNonQuery("[Configuration].[usp_UpdateConfigurationItem]", contextId, key, value) > 0;
        }

        internal bool UpdateConfigurationItemById(int configurationItemId, String value)
        {
            return base.ExecuteNonQuery("[Configuration].[usp_UpdateConfigurationItemById]", configurationItemId, value) > 0;
        }

        protected override ConfigurationItem GetItemFromReader(System.Data.IDataReader dataReader)
        {
            ConfigurationItem configurationItem = new ConfigurationItem();
            configurationItem.ConfigurationItemId = dataReader.GetInt32("ConfigurationItemId");
            configurationItem.ContextId = dataReader.GetNullableInt32("ContextId");
            configurationItem.KeyId = dataReader.GetInt32("KeyId");
            configurationItem.Value = dataReader.GetString("Value");
            configurationItem.Key = dataReader.GetString("Name");
            return configurationItem;
        }

        public List<Context> GetConfigurationContextList()
        {
            DataTable tbl = base.LoadTable("[Configuration].[usp_GetConfigurationContextList]");
            Context context;
            List<Context> contextList = new List<Context>();

            foreach (DataRow item in tbl.Rows)
            {
                context = new Context();
                context.ApplicationId = (int)item["ApplicationId"];
                context.ContextId = (int)item["ContextId"];
                context.Name = (string)item["Name"] + " (ContextId: " + (int)item["ContextId"] + ")";
                contextList.Add(context);
            }
            return contextList.OrderBy(x => x.Name).ToList();
        }

        public List<Key> GetConfigurationContextKeyList(ConfigurationContextKeyListGetRequest request)
        {
            DataTable tbl = base.LoadTable("[Configuration].[usp_GetConfigurationContextKeyList]", request.ContextId);
            Key key;
            List<Key> keyList = new List<Key>();

            foreach (DataRow item in tbl.Rows)
            {
                key = new Key();
                key.KeyId = (int)item["KeyId"];
                key.Name = (string)item["Name"];

                keyList.Add(key);
            }
            return keyList.OrderBy(x => x.Name).ToList();
        }

        public List<ConfigurationItem> GetConfigurationOfKey(int keyId)
        {
            return base.GetEntityList("[Configuration].[usp_GetConfigurationItem_ByKeyId]", keyId);
        }

        internal StringDictionary GetEnvironmentConfigurations(string environment)
        {
            DataTable tbl = base.LoadTable("[Configuration].[usp_GetEnvironmentConfigurations]", environment);
            StringDictionary results = new StringDictionary();
            foreach (DataRow item in tbl.Rows)
            {
                results.Add((string)item["ConfigurationName"], (string)item["Value"]);
            }
            return results;
        }
        public List<Context> GetConfigurationContextListByApplicationId(int applicationId)
        {
            DataTable tbl = base.LoadTable("[Configuration].[usp_GetConfigurationContextListByApplicationId]", applicationId);
            Context context;
            List<Context> contextList = new List<Context>();

            foreach (DataRow item in tbl.Rows)
            {
                context = new Context();
                context.ApplicationId = (int)item["ApplicationId"];
                context.ContextId = (int)item["ContextId"];
                context.Name = (string)item["Name"] + " (ContextId: " + (int)item["ContextId"] + ")";
                contextList.Add(context);
            }
            return contextList.OrderBy(x => x.Name).ToList();
        }
        public List<ConfigurationItemSummary> GetConfigurationItemSummary(int contextId)
        {
            DataTable tbl = base.LoadTable("[Configuration].[usp_GetConfigurationItemSummary]", contextId);
            List<ConfigurationItemSummary> sumarryList = new List<ConfigurationItemSummary>();

            foreach (DataRow item in tbl.Rows)
            {
                    var sumarry = new ConfigurationItemSummary();
                    if (!item.IsNull("Desc"))
                    {
                        sumarry.Desc = (string)item["Desc"];
                    }
                    if (!item.IsNull("KeyId"))
                    {
                        sumarry.KeyId = (int)item["KeyId"];
                    }
                    if (!item.IsNull("Name"))
                    {
                        sumarry.Name = (string)item["Name"];
                    }
                    if (!item.IsNull("Value"))
                    {
                        sumarry.Value = (string)item["Value"];
                    }
                    sumarryList.Add(sumarry);

            }
            return sumarryList.OrderBy(x => x.KeyId).ToList();
        }

        internal bool UpdateConfigurationItemByKeyId(int contextId, int keyId, String value)
        {
            return base.ExecuteNonQuery("[Configuration].[usp_UpdateConfigurationItemByKeyId]", contextId, keyId, value) > 0;
        }
        internal bool UpdateEnvironmentConfiguration(UpdateEnvironmentConfigurationRequest request)
        {
            return base.ExecuteNonQuery("[Configuration].[usp_UpdateEnvironmentConfiguration]", request.Environment, request.ConfigurationName, request.Value) > 0;
        }

    }
}
