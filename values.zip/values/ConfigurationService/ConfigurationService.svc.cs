﻿using ConfigurationService.DataAccess;
using ServiceContract.Contracts.Configuration;
using ServiceContract.Dispatcher;
using ServiceContract.Entities.Configuration;
using ServiceContract.Services;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Reflection;
using System.ServiceModel;

namespace ConfigurationService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in code, svc and config file together.
    [ServiceBehavior(InstanceContextMode = InstanceContextMode.Single, ConcurrencyMode = ConcurrencyMode.Multiple)]
    [ErrorHandlerBehaviour]
    public class ConfigurationService : IConfigurationService
    {
        public ConfigurationService()
        {
            Global.Log("ConfigurationService Initializing", "ConfigurationService");
            //ConfigurationDALC dalc = new ConfigurationDALC();
            //int appId = dalc.GetApplicationIdOfContext(6);
            Global.Log("ConfigurationService Initialized", "ConfigurationService");
        }

        #region IConfigurationService Members

        public ConfigurationResponse GetConfiguration(ConfigurationRequest request)
        {
            int appId = 2;
            StringDictionary dict = new StringDictionary();
            try
            {
                Global.Log("GetConfiguration is called:" + request.ContextId , "ConfigurationService");
                ConfigurationDALC dalc = new ConfigurationDALC();
                appId = dalc.GetApplicationIdOfContext(request.ContextId);
                List<ConfigurationItem> list = dalc.GetConfigurationOfContext(request.ContextId);

                foreach (ConfigurationItem item in list)
                {
                    dict.Add(item.Key, item.Value);
                }
            }
            catch (Exception ex)
            {
                ReflectionTypeLoadException reflectionTypeLoadException = ex as ReflectionTypeLoadException;
                if (reflectionTypeLoadException != null)
                {
                    Global.Log(" reflectiontype : " + ex.GetType(), "ConfigurationService");
                    foreach (Exception loadException in reflectionTypeLoadException.LoaderExceptions)
                    {
                        Global.LogException(loadException, "ConfigurationService");
                    }
                }
                else
                {
                    Global.Log("Not reflectiontype : " + ex.GetType(), "ConfigurationService");
                    Global.LogException(ex, "ConfigurationService");

                }
            }
            ConfigurationResponse response = new ConfigurationResponse();
            response.ApplicationId = appId;
            response.Configuration = dict;
            return response;
        }

        public void AddConfigurationItem(ConfigurationAddRequest request)
        {
            ConfigurationDALC dalc = new ConfigurationDALC();
            dalc.AddConfigurationItem(request.ContextId, request.Key, request.Desc, request.Value);
        }

        public void DeleteConfigurationItem(ConfigurationDeleteRequest request)
        {
            ConfigurationDALC dalc = new ConfigurationDALC();
            dalc.DeleteConfigurationItem(request.ContextId, request.Key);
        }

        #endregion


        public ConfigurationUpdateResponse UpdateConfigurationItem(ConfigurationUpdateRequest request)
        {
            ConfigurationDALC dalc = new ConfigurationDALC();
            int appId = request.Context.ApplicationId;

            bool result = dalc.UpdateConfigurationItem(request.ContextId, request.Key, request.Value);
            return new ConfigurationUpdateResponse { Result = result };
        }

        public ConfigurationUpdateResponse UpdateConfigurationItemById(ConfigurationUpdateRequest request)
        {
            ConfigurationDALC dalc = new ConfigurationDALC();
            bool result = dalc.UpdateConfigurationItemById(request.ConfigurationItemId, request.Value);
            return new ConfigurationUpdateResponse { Result = result };
        }

        public ConfigurationContextListGetResponse GetConfigurationContextList()
        {
            ConfigurationDALC dalc = new ConfigurationDALC();
            ConfigurationContextListGetResponse response = new ConfigurationContextListGetResponse();
            response.ContextList = dalc.GetConfigurationContextList();
            return response;
        }

        public ConfigurationContextKeyListGetResponse GetConfigurationContextKeyList(ConfigurationContextKeyListGetRequest request)
        {
            ConfigurationDALC dalc = new ConfigurationDALC();
            ConfigurationContextKeyListGetResponse response = new ConfigurationContextKeyListGetResponse();
            response.ContextKeyList = dalc.GetConfigurationContextKeyList(request);
            return response;
        }

        public ConfigurationItemGetResponse GetConfigurationItem(ConfigurationItemGetRequest request)
        {
            ConfigurationDALC dalc = new ConfigurationDALC();
            List<ConfigurationItem> list = dalc.GetConfigurationOfKey(request.KeyId);
            ConfigurationItemGetResponse response = new ConfigurationItemGetResponse();
            if (list.Count > 1)
            {
                response.ConfigurationItem = list.Find(x => x.ContextId == request.ContextId);
            }
            else // contexti olmayan configitemlar için 
            {
                response.ConfigurationItem = list[0];
            }

            return response;
        }


        public EnvironmentConfigurationResponse GetEnvironmentConfigurations(EnvironmentConfigurationRequest req)
        {
            ConfigurationDALC dalc = new ConfigurationDALC();
            StringDictionary configurations = dalc.GetEnvironmentConfigurations(req.Environment);
            EnvironmentConfigurationResponse response = new EnvironmentConfigurationResponse { Configurations = configurations };
            return response;
        }


        public ConfigurationContextListGetResponse GetConfigurationContextListByApplicationId(int applicationId)
        {
            ConfigurationDALC dalc = new ConfigurationDALC();
            ConfigurationContextListGetResponse response = new ConfigurationContextListGetResponse();
            response.ContextList = dalc.GetConfigurationContextListByApplicationId(applicationId);
            return response;
        }
        public List<ConfigurationItemSummary> GetConfigurationItemSummary(int contextId)
        {
            ConfigurationDALC dalc = new ConfigurationDALC();
            List<ConfigurationItemSummary> response = new List<ConfigurationItemSummary>();
            response = dalc.GetConfigurationItemSummary(contextId);
            return response;
        }
        public ConfigurationUpdateResponse UpdateConfigurationItemByKeyId(ConfigurationUpdateRequest request)
        {
            ConfigurationDALC dalc = new ConfigurationDALC();
            bool result = dalc.UpdateConfigurationItemByKeyId(request.ContextId, request.KeyId, request.Value);
            return new ConfigurationUpdateResponse { Result = result };
        }

        public UpdateEnvironmentConfigurationResponse UpdateEnvironmentConfiguration(UpdateEnvironmentConfigurationRequest request)
        {
            ConfigurationDALC dalc = new ConfigurationDALC();
            bool result = dalc.UpdateEnvironmentConfiguration(request);
            return new UpdateEnvironmentConfigurationResponse { Result = result };
        }
    }
}
